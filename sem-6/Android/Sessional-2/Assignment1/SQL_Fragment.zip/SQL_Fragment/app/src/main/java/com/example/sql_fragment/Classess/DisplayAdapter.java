package com.example.sql_fragment.Classess;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sql_fragment.R;

import java.util.ArrayList;

public class DisplayAdapter extends RecyclerView.Adapter<DisplayViewHolder> {
    private ArrayList<Student> studentArrayList = new ArrayList<>();
    @NonNull
    @Override
    public DisplayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student,parent,false);
        return new DisplayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DisplayViewHolder holder, int position) {
        Student student = studentArrayList.get(position);
        holder.tv_firstName.setText("First name :" +student.getFirstName());
        holder.tv_secondName.setText("Last name :" +student.getLastName());
        holder.tv_contactNo.setText("Contact No :" +student.getContactNo());
        holder.tv_rollNo.setText("Roll No :" +student.getRollNo());
        holder.tv_address.setText("Address :" +student.getAddress());
    }

    public void updateList(ArrayList<Student> students){
        studentArrayList.clear();
        studentArrayList.addAll(students);
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        return studentArrayList.size();
    }
}
