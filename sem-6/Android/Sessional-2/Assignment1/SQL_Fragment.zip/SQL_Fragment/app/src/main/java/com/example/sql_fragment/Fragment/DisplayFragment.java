package com.example.sql_fragment.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.sql_fragment.Classess.DBManager;
import com.example.sql_fragment.Classess.DisplayAdapter;
import com.example.sql_fragment.Classess.Student;
import com.example.sql_fragment.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DisplayFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DisplayFragment extends Fragment {
    private Button btn_submit;
    private RecyclerView recyclerView;

    public DisplayFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_display, container, false);
        btn_submit = view.findViewById(R.id.btnDisplay);
        recyclerView = view.findViewById(R.id.rvStudent);
        DBManager dbManager = new DBManager(requireContext());
        dbManager.openDB();
        ArrayList<Student> students = dbManager.fetchAllQuery();
        DisplayAdapter displayAdapter = new DisplayAdapter();
        recyclerView.setAdapter(displayAdapter);

        displayAdapter.updateList(students);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getParentFragmentManager().beginTransaction().replace(R.id.main_fragment_page, new StudentFragment()).commit();
            }
        });
        return  view;
    }
}