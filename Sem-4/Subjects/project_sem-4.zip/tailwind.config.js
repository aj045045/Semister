/** @type {import('tailwindcss').Config} */
module.exports = {
  prefix:"tw-",
  content: ['./Department/{admin,links}/**/*.php','./Department/*.php'],
  theme: {
    extend: {},
  },
  plugins: [],
}
