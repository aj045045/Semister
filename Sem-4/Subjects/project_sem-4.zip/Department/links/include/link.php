<?php
//  // // TODO: Link files 

echo '
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script> <!-- // @audit-info :jquery link -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- // @audit-info :font awesome -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> 
<link rel="stylesheet" href="links/bs5/bootstrap.min.css"><!-- // @audit-info : bootstrap -->
<script src="links/bs5/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="./links/css/main.css"> <!-- // @audit-info :main css  -->
<link rel="stylesheet" href="./links/css/output.css"> <!-- // @audit-info :tailwind css  -->
<link rel="stylesheet" href="./links/css/global.css"> <!-- // @audit-info :global css  -->
<title>Depart. of Computer science</title> <!-- // @audit-info :icons and titles css  -->
<script src="./links/aos/aos.js"></script> <!-- // @audit-info :Animation on scroll js  -->
<link href="./links/aos/aos.css" rel="stylesheet">  <!-- // @audit-info :Animation on scroll css  -->
<link rel="shortcut icon" href="image/logos/logo.webp" type="image/png">
<script>
  AOS.init();
</script>
';
