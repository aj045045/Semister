<!-- //  TODO: About page
-->
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include "links/include/link.php" ?>
    <style>
        .hpc-images{
            height:600px !important;
        }
    </style>
    <a href="./../"></a>
</head>

<body>

    <!-- Scroll button -->
    <?php include "links/include/header.php" ?>
    <div class="container" style="padding-right:7%;padding-left:7%;">
    <ul class="breadcrumb" style="padding-top:130px">
            <li><a href="home.php">Home</a></li>
            <li>Why DCS</li>
            <li>HPC systems</li>
        </ul>
        <br>
        <img src="image/hpc/hpc2.jpeg" class="my-2 w-100 hpc-images img-fluid" alt="">        
        <img src="image/hpc/hpc1.jpeg" class="my-2 w-100 hpc-images img-fluid" alt="">        
        <img src="image/hpc/hpc3.jpeg" class="my-2 w-100 hpc-images img-fluid" alt="">        
    </div>
    <br><br><br>
    <?php include "links/include/footer.php" ?>
</body>

</html>