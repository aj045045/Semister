<!-- //  TODO: About page
-->
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include "links/include/link.php" ?>
    <style>
        p {
            text-align: justify;
        }
    </style>
    <a href="./../"></a>
</head>

<body>

    <!-- Scroll button -->
    <?php include "links/include/header.php" ?>
    <div style="padding-right:7%;padding-left:7%;">
        <br>
        <ul class="breadcrumb" style="padding-top:130px">
            <li><a href="home.php">Home</a></li>
            <li>Why DCS</li>
            <li>#1 Gujarat</li>
        </ul>
        <div class="container">
            <div class="pill">#1 Gujarat</div>
            <br>
            <p>Gujarat University is ranked as the #1 University in the NIRF Rankings, with Gujarat University also
                emerging as the #1 University under the Gujarat State Institutional Ranking Framework recently. The
                spirit of ingenuity and innovation reigns supreme at Gujarat University, a fact best represented by it
                emerging in the top 9 Institutions in India in the Atal Rankings of Institutions on Innovative
                Achievement (ARIIA) Rankings.

            </p>
        </div>

    </div>
    <br><br><br>
    <?php include "links/include/footer.php" ?>
</body>

</html>