# tailwind link for run tailwind
 npx tailwindcss -i ./Department/links/css/tailwind/input.css -o ./Department/links/css/output.css --watch

# Project

## Goals,Opportunity and Objectives :
> What the `system ` is trying to do \
> Scope of project
> SIGN IN
> Password view
> Calender of events and reminder with email

<br/>

## Requirements :
> Works of Faculty, Admin, Student and other user \
> Who (include ), What( project ), Where ( pages ), When ( pages ), How( system ), Why 

<br/>

## Analysis :
- [ ] Data flow diagrams
    - Before data flow diagram create SFS
- [ ] Activity diagram
- [ ] Sequence diagram
- [ ] Data dictionary

<br/>
# SFS Reports of projects

### TASK'S
</br>

> `Signin` / Signup \
> `Student's` [  ]
> `Faculty` [ Details rank wise ]
> `Events`  [ Faculty :add Member, Student : participate, manager ] \
> `Feed back` [ Website, Events] \
> `Profile` dashboard [ Student and faculty/ Event participation history ] \
> Exam `Result` \
> `Authentication` with emails \
> `Syllabus` \
> `News` Letter \
> `Admin` can manage student and faculty [ May change their profile except Name and password's ]\
> Viewers can see the `achievements` of department's



## SRS DETAILS



## Dfd's
- [ ] For `Users`
```
- Sign in
- Sign up
- Downloads
- Dashboard
- News & letter
```
</br>

- [ ] For `Students`
```
- Result
- Events
```
</br>

- [ ] For `Faculty`
```
- Research
- Awards
- Change syllabus pdf's
```
</br>



## Design :
```
Logical design [ create wireframes of webpages ] 
Database  [ create er model ]
```
<br/>

## Emplementations :
<br/>

## Testing :
<br/>

## Managements :
<br/>

## FILES USES :
- Js folder
  - js header and footer
  - js files

- Css folder
  - global css
  - web page

- php folder
   -  php works files

- All files as globals files

<br/>

##  Database
- Contains  `images`
- Contains whole data description of admin, faculty, students
- 
 

## SRS Reports
```
We will make a Department Management System For Department of Computer Science ,Gujarat University. We will gather information about students studying ,faculties and also about the events 
along with the course information . We also gather information about students studying in course,students participation in Events , Profile Management for student and faculty 
both.
```
```	
In our System we will provide sign up for both student and faculty. New user has to register himself before signing up. User can view  and edit their profile
after sign in. Faculty can add their research work in their profile and also add their details in order according to their ranks. Students can see their events 
particiapation history and faculty can see the list of event managed/created by them. In event pages the list of events are shown in order of recently created events. 
The user can see the details of events. The event manager (event manager can be faculty or admin) who will update/delete/submit the event as per needs, event can be submited at the alloted time 
```
```
It will added in event list. Events may have student member list who will coordinate with event manager to help them in manageing the event. Participated student may
provide the event feedback. Same event can be enrolled as per needs and time . Feedback are the user experience of the particular event. Student can view their syllabus in their Results in the Result page .It can be updated by faculty . Achievements of our Department will be displayed in our 
website. Achievements can only be updated by Admin. Viewers can see these achievements of department . 
```
```
Admin can manage student ,faculty,events,syllabus  profile.
```