<?php
// ---------Abstract class and method------------------------
abstract class Person
{
    private $fname, $lname, $email, $mobile;
    public function __construct($fname, $lname)
    {
        $this->fname = $fname;
        $this->lname = $lname;
    }
    //  fname
    public function getFName()
    {
        return $this->fname;
    }
    public function setFName($value)
    {
        $this->fname = $value;
    }
    //  lname
    public function getLName()
    {
        return $this->lname;
    }
    public function setLName($value)
    {
        $this->lname = $value;
    }
    //  email
    public function getEmail()
    {
        return $this->email;
    }
    public function setEmail($value)
    {
        $this->email = $value;
    }
    //  mobile
    public function getMobile()
    {
        return $this->mobile;
    }
    public function setMobile($value)
    {
        $this->mobile = $value;
    }
    //  fullname
    abstract public function getFullName();
}

class Employee extends Person
{
    private $eid, $edept;
    public function __construct($fname, $lname, $eid, $edept)
    {
        $this->eid = $eid;
        $this->edept = $edept;
        parent::__construct($fname, $lname);
    }
    //  eid
    public function geteid()
    {
        return $this->eid;
    }
    public function seteid($value)
    {
        $this->eid = $value;
    }
    //  edept
    public function getdept()
    {
        return $this->edept;
    }
    public function setedept($value)
    {
        $this->edept = $value;
    }
    //  getfullname
    public function getfullname()
    {
        $fullname = $this->getfname() . ' ' . $this->getlname();
        return $fullname;
        return $this->fname;
    }
}
$emp = new Employee('first', 'last', 1, 'IT');
print_r($emp);
$ans = $emp->getfullname();
echo "<br> $ans";

// ---------------------------static------------------------------
class Employee
{
    private $eid, $ename;
    public static $objcount = 0; // define a static properties
    public $total = 0;
    public function __construct($eid, $ename)
    {
        $this->eid = $eid;
        $this->ename = $ename;
        self::$objcount++;
    }
    //  eid
    public function geteid()
    {
        return $this->eid;
    }
    public function seteid($value)
    {
        $this->eid = $value;
    }
    //  ename
    public function getename()
    {
        return $this->ename;
    }
    public function setename($value)
    {
        $this->ename = $value;
    }
    public static function objectcount()
    {
        return self::$objcount;
    }
}
$obj1 = new Employee(1, 'One');
echo "<br>" . Employee::objectcount();
$obj2 = new Employee(2, 'Two');
echo "<br>" . Employee::$objcount;
$obj3 = new Employee(3, 'Three');
echo "<br>" . Employee::objectcount();
$obj4 = new Employee(4, 'Four');
echo "<br>" . Employee::objectcount();

class Employee
{
    private $eid, $ename;  //properties of a class Employee
    public function __construct($eid, $ename)
    {
        $this->eid = $eid;
        $this->ename = $ename;
    }
    //  Getter and setter to set properties of object
    public function geteid() //get method to get employeeid
    {
        return $this->eid;
    }
    public function seteid($value) //set method to set employeeid
    {
        $this->eid = $value;
    }
    public function getename()
    {
        return $this->ename;
    }
    public function setename($value)
    {
        $this->ename = $value;
    }
}
$obj = new Employee(1, 'Abhay');
echo "<br> is class Employee exists: ";
// class_exists
$ans1 = class_exists('Employee');
echo " $ans1 ";
//  get class
$ans2 = get_class($obj);
echo "<br> obj is object of class : $ans2";
// is_a
$ans3 = is_a($obj, 'Employee');
if ($ans3 == true) {
    echo "<br> obj is an object of class Employee ";
} else {
    echo "<br> obj is not an object of class Employee";
}
// property_exists
$ans4 = property_exists($obj, 'eid');
if ($ans4 == true) {
    echo "<br> property eid exists for object obj ";
} else {
    echo "<br> property eid does not exist for object obj ";
}
// method_exists
$ans5 = method_exists($obj, 'geteid');
if ($ans5 == true) {
    echo "<br> method geteid exists for object obj ";
} else {
    echo "<br> method geteid does not exist for object obj ";
}
