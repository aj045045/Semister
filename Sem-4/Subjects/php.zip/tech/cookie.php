<?php
$name = 'Nidhi';
$value = 'password123';
$exp = time() + 86400;
echo "<br> $exp";
setcookie($name,$value,$exp);
echo "<br> Cookie is set";


//---------------------------------------------


$name = $_COOKIE['Nidhi'];
echo "<br> The value of cookie is :". $name;

//---------------------------------------------

$expire = time() - 86400;
$name = 'Nidhi';
setcookie($name,'',$expire);
if(isset($_COOKIE['Nidhi']))
{
echo "<br> Cookie is set";
}
else
{
echo "<br> Cookie is not set";
}


//---------------------------------------------

$name = 'Nidhi';
$value = 'password123';
$exp = time() + 86400;
echo "<br> $exp";
setcookie($name,$value,$exp);
echo "<br> Cookie is set";
setcookie('Age',19,$exp);
echo "<br> 2nd Cookie is set <br>";
print_r($_COOKIE);

//---------------------------------------------


//---------------------------------------------
?>