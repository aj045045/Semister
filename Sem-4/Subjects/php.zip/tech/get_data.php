<?php

// Simulate getting data from a database
$data = array(
    'name' => 'John Doe',
    'email' => 'johndoe@example.com',
    'place'=>'workshop'
);

// Convert data to JSON format
$json = json_encode($data);

// Set response header to indicate JSON data
header('Content-Type: application/json');

// Output JSON data
echo $json;
?>