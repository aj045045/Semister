<html>
<body>
<form action='exec.php' method='post'>
<table>
<!-- vid -->
<tr>
<td>Vendor ID:</td>
<td> <input type='text' name='vid'> </td>
</tr>
<!-- vname -->
<tr>
<td>Vendor Name:</td>
<td> <input type='text' name='vname'> </td>
</tr>
<!-- vaddress -->
<tr>
<td>Vendor Address:</td>
<td> <input type='text' name='vaddress'> </td>
</tr>
<!-- vcity -->
<tr>
<td> Vendor City: </td>
<td> <input type='text' name='vcity'> </td>
</tr>
<!-- vmobile -->
<tr>
<td> Vendor Mobile: </td>
<td> <input type='text' name='vmobile'> </td>
</tr>
<!-- submit and reset -->
<tr>
<td> <input type='submit' name='submit' value='Submit'> </td>
<td> <input type='reset' name='reset' value='Reset'> </td>
</tr>
</table>
</form>
</body>
</html>