
<?php
// $dsn = "mysql:host=localhost;dbname=demodb";
// $uname = "root";
// $pwd = "";
// $conn = new PDO($dsn,$uname,$pwd);
// $result = $conn->query("SELECT * FROM vendor");
// $result = $conn->query("SELECT * FROM vendor WHERE vid = 2");

//----------------------fetch-----------------------
// PDO::FETCH_ASSOC
// PDO::FETCH_NUM
// PDO::FETCH_BOTH
// PDO::FETCH_OBJ

// while($row = $result->fetch(PDO::FETCH_ASSOC)){
//     echo "{$row['vid']} - {$row['vname']} - {$row['vaddress']} - {$row['vcity']} - {$row['vmobile']} <br>";
//     echo "{$row[0]} - {$row[1]} - {$row[2]} - {$row[3]} - {$row[4]} <br>";
//     echo "{$row->vid} - {$row->vname} - {$row->vaddress} - {$row->vcity} - {$row->vmobile} <br>";
//     echo "<pre>";
//     print_r($row);
//     echo "<pre>";
// }
//-----------------------fetchAll---------------------
// $row = $result->fetchAll(PDO::FETCH_NUM);
// echo "<pre>";
//     print_r($row);
//     echo "<pre>";

//     if(count($row)){
//         foreach($row as $data){
//             echo "{$data[1]} - {$data[2]} <br>";
//         }
//     }

//--------------------------prepare-------------------------

// $result = $conn->prepare("SELECT * FROM vendor");
// $id = 1;
// $vname = "abc";

// $result = $conn->prepare("SELECT * FROM vendor WHERE vid = ? AND vname = ?");
// // $result->execute(array($id,$vname));
// $result->bindParam(1,$id,PDO::PARAM_INT);
// $result->bindValue(2,$vname,PDO::PARAM_INT);
// $result->execute();

// PDO::PARAM_INT
// PDO::PARAM_STR
// PDO::PARAM_LOB
// PDO::PARAM_BOOL
// PDO::PARAM_NULL
//-------------------INSERT---------------------
// $name= "ghfrh";
// $address = "ahbad";
// $city = "abad";
// $mobile = 9748563548;
// $addData = $conn->prepare("INSERT INTO vendor (vname,vaddress,vcity,vmobile) VALUES (:name, :add , :city, :mobile )");
// $addData->execute(array(':name' => $name, ':add' => $address, ':city' => $city, ':mobile' => $mobile));
// $result = $conn->prepare("SELECT * FROM vendor");
// $result->execute();
// $row = $result->fetchAll(PDO::FETCH_NUM);
// echo "<pre>";
//     print_r($row);
//     echo "<pre>";
//     if(count($row) !== 0){
//         foreach($row as $data){
//             echo "{$data[1]} - {$data[2]} <br>";
//         }
//     }

//--------------------city---------------------


// $vcity = $_POST['city'];
// $query = "select * from vendor where vcity = '$vcity'";
// $query = "delete from vendor where vid = 9";
// $query = "update vendor set vname='p1', vcity='ahmedabad' where vid = 2";

// echo "<br> Query : $query <br>";
// $result = $conn->prepare($query);
// $result->execute();
// $row = $result->fetch();

// while($row != null)
// {
// $vid = $row['vid'];
// $vname = $row['vname'];
// $vaddress = $row['vaddress'];
// $vcity = $row['vcity'];
// $vmobile = $row['vmobile'];
// echo "<br>";
// echo "<br> Vendor ID : $vid";
// echo "<br> Vendor Name: $vname";
// echo "<br> Vendor Address: $vaddress";
// echo "<br> Vendor City : $vcity";
// echo "<br> Vendor Mobile : $vmobile";
// $row = $result->fetch();
// }
// $result->closeCursor();
$dsn = "mysql:host=localhost;dbname=demodb";
$uname = "root";
$pwd = "";
$conn = new PDO($dsn,$uname,$pwd);

$result = $conn->prepare("select * from vendor");
$result->execute();
$rows = $result->fetchAll();
foreach($rows as $row)
{
$vid = $row['vid'];
$vname = $row['vname'];
$vaddress = $row['vaddress'];
$vcity = $row['vcity'];
$vmobile = $row['vmobile'];
echo "<br>";
echo "<br> Vendor ID : $vid";
echo "<br> Vendor Name: $vname";
echo "<br> Vendor Address: $vaddress";
echo "<br> Vendor City : $vcity";
echo "<br> Vendor Mobile : $vmobile";
}

$result->closeCursor();
?>