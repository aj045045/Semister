<?php

$i2 = new DateInterval('P1Y23D'); // 1 Year 23 Days
$i3 = new DateInterval('PT1H2M12S'); // 1 Hour 2 Minutes 12 Second
$i4 = new DateInterval('P1Y23DT2H5M12S'); // 1 Year 23 Days 2 Hours 5 Minutes 12 Seconds
print_r($i4);

$i5 = new DateInterval('P2M10D');
echo "<br>" . $i5->format('%m months, %d days');


$votingage = new DateInterval('P10Y');
$dob = new DateTime();
$dob->sub($votingage);
$dob2 = new DateTime();
$dob2->add($votingage);
//Initialising the two datetime objects
$datetime1 = new DateTime('2019-9-10');
$datetime2 = new DateTime('2019-9-15');
$difference = $datetime1->diff($datetime2);
echo $difference->format('%R%d days');
echo '<br> You can vote only if you were born on or before: ' . $dob->format('j/n/Y');
echo '<br> You can vote only if you were born on or before: ' . $dob2->format('j/n/Y');

//  CREATE TABLE date_test (
//      id INT AUTO_INCREMENT PRIMARY KEY,
//      created_at DATETIME
//  )

$dsn = "mysql:host=localhost;dbname=demodb";
$uname = "root";
$pwd = "";
$conn = new PDO($dsn, $uname, $pwd);
$addData = $conn->prepare("INSERT INTO date_test( created_at ) 
VALUES( '2018-12-05 12:39:16' );");
$addData->execute();
echo "data insert successfully....";
$result = $conn->prepare("SELECT * FROM date_test 
WHERE DATE(created_at) = '2018-12-05'");
$result->execute();
$row = $result->fetchAll(PDO::FETCH_NUM);
echo "<pre>";
print_r($row);
echo "<pre>";

foreach ($row as $data) {
    echo "{$data[0]} - {$data[1]} <br>";
    $diff = strtotime(date('Y-m-d H:i:s')) - strtotime($data[1]);
    echo "Difference is $diff seconds\n";
    $days = floor($diff / (3600 * 24));
    echo "Difference is $days days\n";
}

$result->closeCursor();
