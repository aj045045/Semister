<?php

// $total_arg = array);
function fact($arg1,$arg2,$arg3)
{
$count = func_num_args();
$total = func_get_arg($arg2);
// array_push($total_arg,$total);

echo "<br> This function has $count arguments";
echo "<br> This function has $total total arguments";

}

fact(11,12,13);
// fact(1,2);
// fact('hgdvgf','fhgj');



// $myfile = fopen("data.txt","r")or die("Unable to open file!");
// Output one line until end-of-file
// while(!feof($myfile)) {
//  echo fgets($myfile) ."<br>";
// }
// fclose($myfile);

// $myfile = fopen("data.txt","a") or die("Unable to open file!");
// $txt = "\nDonald Duck\n";
// fwrite($myfile, $txt);
// $txt = "Goofy Goof\n";
// fwrite($myfile, $txt);
// fclose($myfile);


// $file = fopen("data.txt","w+");
// // exclusive lock
// if(flock($file,LOCK_EX)) {
// fwrite($file,"Add some text to the file.");
// fflush($file);
// flock($file,LOCK_UN);
// }else{
// echo "Error locking file!";
// }
// fclose($file);

// $filename = 'data.txt';
// $functions = [
// 	'is_readable',
// 	'is_writable',
// 	'is_executable'
// ];
// foreach ($functions as $f) {
// 	echo $f($filename) ? 'The file ' . $filename . $f. '<br>' : 
//     'the file ' . $filename . ' not '. $f;
// } 

?>

