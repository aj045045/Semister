<?php
// session_destroy();
session_start();

// Check if the user is already authenticated
if (isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true) {
    // Redirect to the homepage or other authenticated area
    header('Location: /php/php/tech/fullform.php');
    exit;
}

// Check if the user has submitted the login form
if (isset($_POST['username']) && isset($_POST['password'])) {
    // Authenticate the user against a database or other data source
    $username = $_POST['username'];
    $password = $_POST['password'];
    if ($username === 'myusername' && $password === 'mypassword') {
        // Set the session variable to indicate that the user is authenticated
        $_SESSION['authenticated'] = true;
        // Redirect to the homepage or other authenticated area
        session_destroy();
        header('Location: /php/php/tech/fullform.php');
        exit;
    } else {
        // Display an error message
        $error = 'Invalid username or password';
    }
}
?>

<!-- Display the login form -->
<form method="post">
    <label for="username">Username:</label>
    <input type="text" name="username" id="username">
    <br>
    <label for="password">Password:</label>
    <input type="password" name="password" id="password">
    <br>
    <input type="submit" value="Login">
</form>
<?php if (isset($error)) { echo $error; } ?>
