<?php
//  session_start();
//  echo "<br> Session is started";

 //-------------------------------------------------

//Start a session with Custom cookie parameters
// $lifetime = 60 * 60 * 24 * 7 ; //1 week 
// session_set_cookie_params($lifetime , '/');
// session_start();
// echo "<br> session is started <br>"; 
// $ans = $_COOKIE['PHPSESSID'];
// echo "<br> Value of session cookie is : ".$ans;


//---------------------------------------------------------------

//Set a variable in session
// $_SESSION['pcode'] = 'ABC-1234';
// //Get a varibale from a session
// $productcode = $_SESSION['pcode'];
// echo "<br> Product Code is: $productcode";


//----------------------------

//Set an array in a session
// If(!isset($_SESSION['cart']))
// {
// $_SESSION['cart'] = array();
// }
// //Add an element to an array that is stored in a session 
// $_SESSION['cart']['pcode1'] = 'value1';
// $_SESSION['cart']['pcode2'] = 'value2';
// //Get and use an array that’s stored in a session
// $cart = $_SESSION['cart'];
// foreach($cart as $p=>$item)
// {
//  echo '<li>'.$p. ':' . $item.'</li>';
// }

//--------------------------------------------


// If(!isset($_SESSION['cart']))
// {
// $_SESSION['cart'] = array();
// }
// //Add an element to an array that is stored in a session 
// $_SESSION['cart']['pcode1'] = 'value1';
// $_SESSION['cart']['pcode2'] = 'value2';
// //Get and use an array that’s stored in a session
// $cart = $_SESSION['cart'];
// foreach($cart as $p=>$item)
// {
//  echo '<li>'.$p. ':' . $item.'</li>';
// }
// //Remove a session variable
// if(empty($_SESSION['cart']))
// {echo "<br> Session cart is unset";}
// else
// {echo "<br> Session cart is set";}

// unset($_SESSION['cart']);
// if(empty($_SESSION['cart']))
// {
// echo "<br> Session cart is unset";
// }
//Remove all session variable
// $_SESSION = array();
//to display

// $cart = $_SESSION['cart'];
// print_r($cart);
// foreach($cart as $p=>$item)
// {
//  echo '<li>'.$p. ':' . $item.'</li>';
// }


//---------------------------------------------

//Delete the session cookie from the browser
// Get name of session cookie
// $name = session_name();
// // Create expire date in past
// $expire = strtotime('-1 year');
// // $expire = time() + 86400;
// // Get session parameters
// $params = session_get_cookie_params();
// $path = $params['path'];
// $domain = $params['domain'];
// $secure = $params['secure'];
// $httponly = $params['httponly'];
// setcookie("newcookie",'', $expire, $path, $domain, $secure, $httponly);
// if(isset($_COOKIE[$name]))
// {
// echo "<br> Session cookie is set";
// }
// else
// {
// echo "<br> Session cookie is not set";
// }


//-------------------------------------------------------


//Get the name of the session cookie
// by default PHPSESSID
// session_start();
$name = session_name();
echo "<br> Session name is : ".$name;
//Get the value of the session ID
// for example, 
$id = session_id();
echo "<br> Session id is : ".$id;
//Set the session ID
session_id('abc123');
$newid = session_id();
echo "<br> New Session id is : ".$newid;








 ?>