<?php
$dsn = "mysql:host=localhost;dbname=demodb";
$uname = "root";
$pwd = "";
$conn = new PDO($dsn,$uname,$pwd);

$vid = $_POST['vid'];
$vname = $_POST['vname'];
$vaddress = $_POST['vaddress'];
$vcity = $_POST['vcity'];
$vmobile = $_POST['vmobile'];

$query = "insert into vendor
values($vid,'$vname','$vaddress','$vcity','$vmobile') ";
echo "<br> Query : $query <br>";
$result = $conn->exec($query);
echo "<br> Result is : $result";
if($result > 0)
{
echo "<br> Record Insrted Successfully";
}
?>