<?php

//--------------------------func_get_args-------------------------------

// function some_func($a, $b) {
// $param = func_get_args();
// print_r($param);
// $param = join(", ", $param);
// echo "Received parameters: $param.\n";
// }
// some_func("abc", 2, 3, 4, "xyz", 6, 7, 8);


// ---------------------------func_get_arg---------------------------------
// function geeks($a, $b, $c) {
//     echo "Print second argument: "
//         . func_get_arg(0) . "\n";
// }
// geeks('hello', 'php', '123');


// ---------------------------------------------------------
// class Employee
// {
//     private $eid, $ename; // properties of a class Employee
// // * Getter and setter to set properties of object
//     public function geteid() //get method to get employee id
//     {
//         return $this->eid;
//     }
//     public function seteid($value) //set method to set employee id
//     {
//         $this->eid = $value;
//     }
//     public function getename()
//     {
//         return $this->ename;
//     }
//     public function setename($value)
//     {
//         $this->ename = $value;
//     }
// }
// $obj = new Employee();
// print_r($obj);
// echo '<br>';
// $obj->seteid(101);
// echo '<br> $obj is after setid is: <br> ';
// print_r($obj);
// $obj->setename('Vipul');
// echo '<br> $obj is after setname is: <br> ';
// print_r($obj);

//---------------------------------------------------------

// class Employee{
// private $eid, $ename; // properties of a class Employee
// public function __construct($eid,$ename)
// {
// $this->eid = $eid;
// $this->ename = $ename;
// }
// // * Getter and setter to set properties of object
// public function geteid() //get method to get employeeid
// {
// return $this->eid;
// }
// public function seteid($value) //set method to set employeeid
// {
// $this->eid = $value;
// }
// public function getename()
// {
// return $this->ename;
// }
// public function setename($value)
// {
// $this->ename = $value;
// }
// }
// $obj = new Employee(101,'Vipul');
// echo '<br> $obj is now : ';
// print_r($obj);
// $obj2 = new Employee(110,'Dhaval');
// echo '<br> $obj2 is now : ';
// print_r($obj2);
// echo '<br>';
// $obj2->seteid(102);
// echo '<br> $obj2 is after setid is: <br> ';
// print_r($obj2);
// $obj2->setename('Vimal');
// echo '<br> $obj2 is after setname is: <br> ';
// print_r($obj2);

//-----------------------------------------------------

// class Employee
// {
// private $dept;
// const H = 'HR';
// const A = 'Admin';
// public function getdept()
// {
// return $this->dept;
// }
// public function setdept($value)
// {
// if($value == self::H || $value == self::A)
// {
// $this->dept = $value;
// }
// else
// {
// exit('Invalid Department');
// }
// }
// }
// $emp = new Employee();
// $emp->setdept(Employee::A);
// echo '<br> You are from '. $emp->getdept() .' Department ';
// * Or you can write
// echo '<br> You are from '. Employee::H .' Department ';


//----------------------------------------------------------------------

// class Employee
// {
// public $eid,$ename;
// private $edept, $esal;
// public function __construct($eid,$ename)
// {
// $this->eid = $eid;
// $this->ename = $ename;
// }
// *eid
// public function geteid()
// {
// return $this->eid;
// }
// public function seteid($value)
// {
// $this->eid = $value;
// }
// *ename
// public function getename()
// {
// return $this->ename;
// }
// public function setename($value)
// {
// $this->ename = $value;
// }
// *edat
// public function getedept()
// {
// return $this->edept;
// }
// public function setedept($value)
// {
// $this->edept = $value;
// }
// *esal
// public function getesal()
// {
// return $this->esal;
// }
// public function setesal($value)
// {
// $this->esal = $value;
// }
// * show
// public function show()
// {
//     echo "<ul>";
//     foreach($this as $name => $value)
//     {
//     echo "<li> $name : $value ";
//     }
//     echo "</ul>";
// }

// }
//     $e = new Employee(1,'One');
//     $e->setedept('IT');
//     $e->setesal(175000);
//     $e->show();
//     echo "<br> Outside class <br>";
//     echo "<ul>";
//     foreach($e as $k=>$v)
//     {
//     echo "<li> $k : $v </li>";
//     }
//     echo "</ul>";

//---------------------------------------------------------

// class Employee
// {
// private $eid, $ename; // properties of a class Employee
// public function __construct($eid,$ename)
// {
// $this->eid = $eid;
// $this->ename = $ename;
// }
// * Getter and setter to set properties of object
// public function geteid() //get method to get employeeid
// {
// return $this->eid;
// }
// public function seteid($value) //set method to set employeeid
// {
// $this->eid = $value;
// }
// *get name
// public function getename()
// {
// return $this->ename;
// }
// public function setename($value)
// {
// $this->ename = $value;
// }
// }
// $obj1 = new Employee(101,'Vipul');
// echo '<br> $obj1 is now : ';
// print_r($obj1);
// $obj2 = new Employee(110,'Dhaval');
// echo '<br> $obj2 is now : ';
// print_r($obj2);
// $obj1 = $obj2;
// echo '<br> after assignment operator now object 2 is <br>';
// print_r($obj2);
// echo '<br> after assignment operator now object 1 is <br>';
// print_r($obj1);
// echo "<br> set name of obj2 to vimal <br>";
// $obj2->setename('Vimal');
// echo '<br> $obj2 is after setname is: <br> ';
// print_r($obj2);
// echo '<br> $obj1 is after obj2 setname is: <br> ';
// print_r($obj1);


//-----------------------------------------

// class Employee
// {
//     private $eid, $ename; // properties of a class Employee
// public function __construct($eid,$ename)
// {
// $this->eid = $eid;
// $this->ename = $ename;
// }
// * Getter and setter to set properties of object
// public function geteid() //get method to get employeeid
// {
// return $this->eid;
// }
// public function seteid($value) //set method to set employeeid
// {
// $this->eid = $value;
// }
// *getName
// public function getename()
// {
// return $this->ename;
// }
// public function setename($value)
// {
// $this->ename = $value;
// }
// }
// $obj1 = new Employee(101,'Vipul');
// echo '<br> $obj1 is now : ';
// print_r($obj1);
// $obj2 = new Employee(110,'Dhaval');
// echo '<br> $obj2 is now : ';
// print_r($obj2);
// $obj1 = clone $obj2;
// echo '<br> after cloning now object 2 is <br>';
// print_r($obj2);
// echo '<br> after cloning now object 1 is <br>';
// print_r($obj1);
// echo "<br> set name of obj2 to vimal <br>";
// $obj2->setename('Vimal');
// echo '<br> $obj2 is after setname is: <br> ';
// print_r($obj2);
// echo '<br> $obj1 is after obj2 setname is: <br> ';
// print_r($obj1);
// $obj2->seteid(111);
// echo '<br> $obj2 is after seteid is: <br> ';
// print_r($obj2);
// echo '<br> $obj1 is after obj2 seteid is: <br> ';
// print_r($obj1);

//---------------------------------------------

// class Person
// {
// private $fname,$lname,$email,$mobile;
// public function __construct($fname,$lname)
// {
// $this->fname = $fname;
// $this->lname = $lname;
// }
// *fname
// public function getfname()
// {
// return $this->fname;
// }
// public function setfname($value)
// {
// $this->fname = $value;
// }
// *lname
// public function getlname()
// {
// return $this->lname;
// }
// public function setlname($value)
// {
// $this->lname = $value;
// }
// *email
// public function getemail()
// {
// return $this->email;
// }
// public function setemail($value)
// {
// $this->email = $value;
// }
// *mobile
// public function getmobile()
// {
// return $this->mobile;
// }
// public function setmobile($value)
// {
//     $this->mobile = $value;
// }
// }
// class Employee extends Person
// {
// private $eid, $edept;
// public function __construct($fname, $lname,$eid,$edept)
// {
// $this->eid = $eid;
// $this->edept = $edept;
// parent::__construct($fname,$lname);
// }
// *eid
// public function geteid()
// {
// return $this->eid;
// }
// public function seteid($value)
// {
// $this->eid = $value;
// }
// *edept
// public function getdept()
// {
//     return $this->edept;
// }
// public function setedept($value)
// {
// $this->edept = $value;
// }
// }
// $emp = new Employee('first','last',1,'IT');
// print_r($emp);
// $emp->setmobile(1234567890);
// echo "<br>";
// print_r($emp);

//---------------------------------------

// class Person
// {
// protected $fname,$lname;
// private $email,$mobile;
// public function __construct($fname,$lname)
// {
// $this->fname = $fname;
// $this->lname = $lname;
// }
// *fname
// public function getfname()
// {
// return $this->fname;
// }
// public function setfname($value)
// {
// $this->fname = $value;
// }
// *lname
// public function getlname()
// {
// return $this->lname;
// }
// public function setlname($value)
// {
// $this->lname = $value;
// }
// *email
// public function getemail()
// {
// return $this->email;
// }
// public function setemail($value)
// {
// $this->email = $value;
// }
// *mobile
// public function getmobile()
// {
// return $this->mobile;
// }
// public function setmobile($value)
// {
// $this->mobile = $value;
// }
// }
// class Employee extends Person
// {
//     private $eid, $edept;
//     public function __construct($fname, $lname,$eid,$edept)
//     {
//     $this->eid = $eid;
//     $this->edept = $edept;
//     parent::__construct($fname,$lname);
//     }
// *eid
//     public function geteid()
//     {
//     return $this->eid;
//     }
//     public function seteid($value)
//     {
//     $this->eid = $value;
//     }
//* edept
//     public function getdept()
//     {
//     return $this->edept;
//     }
//     public function setedept($value)
//     {
//     $this->edept = $value;
// }
// *fullName
// public function getfullname()
// {
// return $this->fname.' '.$this->lname;
// }
// }
// $emp = new Employee('first','last',1,'IT');
// print_r($emp);
// $emp->setmobzile(1234567890);
// echo "<br>";
// print_r($emp);
// $full = $emp->getfullname();
// echo "<h1> $full";

//-------------------------------------------------------

// // interface showable
// interface showable
// {
//     public function show();
// }
// //interface test
// interface test
// {
//     public function disp1($val1);
//     public function disp2($val1, $val2);
// }
// //interface gender
// interface gender
// {
//     const M = 'Male';
//     const F = 'Female';
// }
// // class person
// class Person
// {
//     private $fname, $lname, $email, $mobile;
//     public function __construct($fname, $lname)
//     {
//         $this->fname = $fname;
//         $this->lname = $lname;
//     }
//     //fname
//     public function getfname()
//     {
//         return $this->fname;
//     }
//     public function setfname($value)
//     {
//         $this->fname = $value;
//     }
//     //lname
//     public function getlname()
//     {
//         return $this->lname;
//     }
//     public function setlname($value)
//     {
//         $this->lname = $value;
//     }
//     //email
//     public function getemail()
//     {
//         return $this->email;
//     }
//     public function setemail($value)
//     {
//         $this->email = $value;
//     }
//     //mobile
//     public function getmobile()
//     {
//         return $this->mobile;
//     }
//     public function setmobile($value)
//     {
//         $this->mobile = $value;
//     }
// }
// class Employee extends Person implements showable, test
// {
//     private $dept, $salary;
//     public function __construct($fname, $lname, $dept, $salary)
//     {
//         parent::__construct($fname, $lname);
//         $this->dept = $dept;
//         $this->salary = $salary;
//     }
//     //dept
//     public function getdept()
//     {
//         return $this->dept;
//     }
//     public function setdept($value)
//     {
//         $this->dept = $value;
//     }
//     //salary
//     public function getsalary()
//     {
//         return $this->salary;
//     }
//     public function setsalary($value)
//     {
//         $this->salary = $value;
//     }
//     // implements show mrthod of interface showable
//     public function show()
//     {
//         echo "<br> Full Name :" . $this->getfname() . ' ' . $this->getlname();
//         echo "<br> Dept :" . $this->dept;
//         echo "<br> Salry :" . $this->salary;
//     }
//     public function disp1($val)
//     {
//         echo "<h1> This is disp1 function : $val";
//     }
//     public function disp2($val1, $val2)
//     {
//         echo "<br> Calling Disp2 to display $val1 and $val2";
//     }
// }
// $emp = new Employee('First', 'Last', 'IT', 25000);
// echo "<br>";
// $emp->show();
// echo "<br>";
// $emp->disp2('Good Morning', 'from Disp2');
// echo "<br>";
// $emp->disp1('Greetings');
