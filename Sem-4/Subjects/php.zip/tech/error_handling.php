<?php
// $p = 1000;
// $rate = 10;
// $n = 2;
// $si = ($p*$r*$n)/100;
// echo "Simple Interest for Principal $p, rate $rate for duration $n is : $si";

//----------------------------------

// $cities = array('Ahmedabad','Rajkot','Surat','Vadodara');
// $count = count($cities);
// for($i=0;$i<=$count;$i++)
// {
// echo $cities[$i]."<br>";
// }

//------------------------------

// function simple($p,$r,$n)
// {
// if($p <= 0 || $r <= 0 ||$n <= 0)
// {
// throw new Exception("Please enter valid values");
// }
// $si = ($p*$r*$n)/100;
// echo "<br> Simple Interest is: $si";
// }
// $p = 1000;
// $r = 0;
// $n = 2;
// $ans = simple($p,$r,$n);

// //------------------------------------

// $p = 1000;
// $r = 0;
// $n = 2;
// try
// {
// $ans = simple($p,$r,$n);
// echo "hello";
// }
// catch(Exception $e)
// {
// echo "Error: ".$e->getMessage();
// }
// function simple($p,$r,$n)
// {
// if($p <= 0 || $r <= 0 ||$n <= 0)
// {
// throw new exception("Please enter valid values");
// }
// $si = ($p*$r*$n)/100;
// echo "<br> Simple Interest is: $si";
// }

//-----------------------------------------------

//create custom exception class
// class customException extends Exception
// {
// public function errorMessage()
// {
// $errormsg = "Error on line ".$this->getLine().' in <br>File: '.$this->getFile().
// 'Error Message <b>'.$this->getMessage().'</b><br>Please enter valid inputs';
// return $errormsg;
// }
// }

// function simple($p,$r,$n)
// {
// if($p <= 0 || $r <= 0 ||$n <= 0)
// {
// throw new customException();
// }
// $si = ($p*$r*$n)/100;
// echo "<br> Simple Interest is: $si";
// }
// $p = 1000;
// $r = 0;
// $n = 2;
// try
// {
// $ans = simple($p,$r,$n);
// }
// catch(Exception $e)
// {
// echo "Custom Exception <br>".$e->errorMessage();
// }

//-------------------------------------------

//create custom exception class
// class customException extends Exception
// {
//     public function errorMessage()
//     {
//         $errormsg = "Error on line " . $this->getLine() . ' in <br>File: ' . $this->getFile() .
//             'Error Message <b>' . $this->getMessage() . '</b><br>Please enter valid inputs';
//         return $errormsg;
//     }
// }
// function simple($p, $r, $n)
// {
//     if ($p <= 0 and $r <= 0 and $n <= 0) {
//         throw new customException("invalid");
//     }
//     if ($p <= 0) {
//         throw new Exception("Please enter valid principal");
//     }
//     if ($r <= 0) {
//         throw new Exception("Please enter valid rate");
//     }
//     if ($n <= 0) {
//         throw new Exception("Please enter valid duration");
//     }
//     $si = ($p * $r * $n) / 100;
//     echo "<br> Simple Interest is: $si";
// }
// $p = 0;
// $r = 0;
// $n = 0;
// try {
//     $ans = simple($p, $r, $n);
// } catch (customException $e) {
//     echo "Custom Exception <br>" . $e->errorMessage();
// } catch (Exception $e) {
//     echo $e->getMessage();
// }


//-------------------------------------------------------

//create custom exception class
class customException extends Exception
{
    public function errorMessage()
    {
        $errormsg = "<br> Error on line " . $this->getLine() . ' in <br>File: ' . $this->getFile() .
            "Error Message <b>" . $this->getMessage() . "</b><br>Please enter valid inputs";
        return $errormsg;
    }
}
// inputs
$p = 1000;
$r = 0;
$n = 3;
// function
function simple($p, $r, $n)
{
    $si = ($p * $r * $n) / 100;
    return $si;
}
try {
    try {
        if ($p <= 0) {
            throw new Exception("Please enter valid principal");
        }
        if ($r <= 0) {
            throw new Exception("Please enter valid rate");
        }
        if ($n <= 0) {
            throw new Exception("Please enter valid duration");
        }
        if ($p <= 0 && $r <= 0 && $n <= 0) {
            throw new customException();
        } 
    } catch (Exception $e) {
        echo "<br> Exception :" . $e->getMessage();
        throw new customException();
    }
} catch (customException $e) {
    echo $e->errorMessage();
}
$ans = simple($p, $r, $n);
echo "<br> Simple Interest : $ans";
