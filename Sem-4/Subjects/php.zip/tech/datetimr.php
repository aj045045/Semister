<?php
// $d = date('j/n-Y \a\t G:i a ');
// echo "<br>Today is $d";

// $dt = new DateTime();
// echo $dt->format('d-m-Y h:m:s');
// $dt->setTime(4,07,15);
// echo "<br>".$dt->format('d-m-Y g:i:s a');
// $disp = $dt->format('d-m-Y h:m:s ');
// echo $disp;

// $ts = time();
// echo "<br>The value of current time stamp is : $ts";
// $mts = mktime(10, 10, 00,13, 4, 2012 );
// echo "<br>The new time stamp has value: $mts";
// $chkdt = checkdate(11,30,2015);
// echo "<br> 30 Novemebr 2015 by checkdate returns: $chkdt <br>";


// $invoicedate = new DateTime('2014-03-23 14:30:18');
// $due_date = clone $invoicedate;
// echo "<dr> Invoice date is:".$invoicedate->format('M j Y g:i:s a');
// $due_date->modify('+4 weeks');
// echo "<br> Due Date (After 4 weeks of invoice date) is: ".$due_date->format('M j Y \a\t g:i:s a');

// $dt = new DateTime();
// echo $dt->format('d-m-Y h:m:s');

$tomorrow = strtotime('tomorrow 8am');
$nextday = new DateTime();
echo $nextday->format('d-m-Y h:m:s');
$nextday->setTimestamp($tomorrow);
echo $nextday->getTimestamp();
?>