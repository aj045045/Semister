<html>
<body>
<form action="fetch.php" method="post">
Enter City Name:
<input type="text" name="city">
<br><br>
<input type="submit" name="submit" value="Submit">
<input type="reset" name="reset" value="Reset">
</form>
</body>
</html>