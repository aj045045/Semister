<!-- 
*REVIEW[epic=Program,seq=1] - 1.Write program in PHP and Html which ask user to 
            enter the Amount, rate and Duration in years and calculate and display Simple the simple interest.
-->
<?php
if (isset($_POST['submit'])) {
    $amount = $_POST['amount'] ?: 0;
    $rate = $_POST['rate'] ?: 0;
    $year = $_POST['year'] ?: 0;
    $simpleInterest = ($amount * $rate * $year) / 100;
    echo "<div>The simple interest is : {$simpleInterest}</div>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1_assignment</title>
    <style>
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
            appearance: none;
        }

        div {
            font-size: 1.3cm;
            font-weight: 500;
        }
    </style>
</head>

<body>
    <form method="post">
        <table>
            <tr>
                <td>
                    <label for="amount">Amount:</label>
                </td>
                <td>
                    <input type="number" name="amount" placeholder="eg :1000">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="rate">Rate:</label>
                </td>
                <td>
                    <input type="number" name="rate" placeholder="eg :30%">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="year">Year:</label>
                </td>
                <td>
                    <input type="number" min="1" max="100" name="year" placeholder="eg :5"><br>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" name="submit" value="submit">
                </td>
            </tr>
        </table>
    </form>
</body>

</html>