<!--
*REVIEW - 8.Create a PHP/HTML script which allows user to choose his/her hobbies by checking the
            checkboxes and display the user’s hobbies.
-->
<?php
if (isset($_POST['submit'])) {
    $c1 = isset($_POST['c1']) ? $_POST['c1'] . "<br>" : "";
    $c2 = isset($_POST['c2']) ? $_POST['c2'] . "<br>" : "";
    $c3 = isset($_POST['c3']) ? $_POST['c3'] . "<br>" : "";
    $c4 = isset($_POST['c4']) ? $_POST['c4'] . "<br>" : "";
    $c5 = isset($_POST['c5']) ? $_POST['c5'] . "<br>" : "";
    echo "Your Hobbies are :<br>";
    echo $c1 . $c2 . $c3 . $c4 . $c5;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question no.8</title>
</head>

<body>
    <form method="post" style="padding-top:1cm">
        <input type="checkbox" name="c1" value="Boxing">Boxing <br>
        <input type="checkbox" name="c2" value="Traveling ">Traveling <br>
        <input type="checkbox" name="c3" value="Photography">Photography <br>
        <input type="checkbox" name="c4" value="Zumba">Zumba<br>
        <input type="checkbox" name="c5" value="Podcast">Podcast <br>
        <input type="submit" name="submit">
    </form>
</body>

</html>