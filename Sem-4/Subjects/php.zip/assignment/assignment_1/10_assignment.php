<!-- 
*REVIEW - 10.Create an array of Milk Types and its price.
            i.Display all the types and price.
            ii. Sort the array by price and display.
            iii. Sort the array by milk type and display
-->
<?php
if (isset($_POST['option'])) {
    $arr = array('Whole Milk' => 700, 'Nonfat Milk' => 500, 'Raw Milk' => 100, 'Lactose-free milk' => 800, 'Buttermilk' => 100);
    $val = $_POST['option'];
    if ($val == "Second")
        asort($arr);
    if ($val == "Third")
        ksort($arr);
    foreach ($arr as $key => $value)
        echo "<div>" . $key . " price is " . "<b>" . $value . "</b><br></div>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question no.10</title>
    <style>
        div {
            font-size: 0.7cm;
        }
    </style>
</head>

<body>
    <form method="post" style="padding-top:1cm;">
        <input type="radio" name="option" value="first"> Display all the types and its price <br>
        <input type="radio" name="option" value="Second"> Sort the array by price <br>
        <input type="radio" name="option" value="Third"> Sort the array by milk type <br>
        <input type="submit" name="submit">
    </form>
</body>

</html>