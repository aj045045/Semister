<!-- 
*REVIEW - 9.Create an array of your favorite Punjabi food. Write PHP script to display only even number
            position Punjabi food.
-->
<?php
$arr = array('Butter Chicken', 'Malai Lassi', 'Chole Bhature', 'Paratha', 'Dal Makhani', 'Panner Tikka', 'Punjabi Dal Tadka');
for ($i = 0; $i < sizeof($arr); $i++)
    if ($i % 2 == 0 || $i == 0)
        echo $arr[$i] . "<br>";
?>