<!-- 
*REVIEW - 12.Create a 2-D array which stores card types (‘C’,’H’,’D’,’S’) and rank (2,3,4,5,6,7,8,9,10, J,
            Q,K,A). Each type has 13 ranks. Display total cards by their type and rank in ascending and
            descending order. Then shuffle it and display the cards. 
-->
<?php
$type = array('C', 'H', 'D', 'S');
$rank = array(2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K', 'A');
$hand = array();
$card = array();
foreach ($type as $t) {
    foreach ($rank as $r)
        $cards[] = $t . $r;
}
foreach ($cards as $c)
    echo "&nbsp;" . $c;
echo "<br><br> After shuffle the 5 cards are : <br><br>";
shuffle($cards);
print_r($cards);
for ($i = 0; $i < 5; $i++) {
    $hand[] = array_shift($cards);
}
echo "<br><br>" . implode('&nbsp;&nbsp;', $hand);
?>