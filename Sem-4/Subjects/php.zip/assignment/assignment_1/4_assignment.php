<!--
*REVIEW - 4.Write a PHP/HTML script which ask user to enter StudentID, Name, and marks of the 3
            subjects. The script will display the total marks, percentage and grade. The guideline to
            determine
            Grade is Grade A if percentage >70
            Grade B if percentage >65
            Grade C if percentage >60
            Grade D if percentage >55
            Grade E if percentage >50
            Grade F if percentage < 50.
            Write the same script by using if –else ladder and switch case.
            Make validations that the marks are must be positive integer numbers only. StudentID and
            student Name must be entered.
-->
<?php
if (isset($_POST['submit'])) {
    $id = $_POST['studentId'] ?: "XYZ";
    $name = $_POST['name'] ?: "XYZ";
    $s1 = $_POST['sub1'] ?: 0;
    $s2 = $_POST['sub2'] ?: 0;
    $s3 = $_POST['sub3'] ?: 0;
    $total = $s1 + $s2 + $s3;
    $per = 0.3 * $total;
    switch ($per) {
        case $per >= 70: {
                $grade = "A";
                break;
            }
        case $per >= 65: {
                $grade = "B";
                break;
            }
        case $per >= 60: {
                $grade = "C";
                break;
            }
        case $per >= 55: {
                $grade = "D";
                break;
            }
        case $per >= 50: {
                $grade = "E";
                break;
            }
        case $per < 50: {
                $grade = "F";
                break;
            }
    }
    echo "<div>Student ID : <b><i>{$id}</b></i><br>Name : <b><i>" . strtoupper($name) . "</b></i><br>Percentage : <b><i>{$per}%</b></i><br>Grades : <b><i>{$grade}</i></i></div>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question no.4</title>
    <style>
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        div {
            font-size: 1cm;
            padding: 1cm 0.5cm;
        }
    </style>
</head>

<body>
    <table>
        <form method="post">
            <tr>
                <td><label for="studentId">Student ID :</label></td>
                <td><input type="text" name="studentId" autocomplete="off"></td>
            </tr>
            <tr>
                <td><label for="name">Name :</label></td>
                <td><input type="text" name="name" autocomplete="off" style='text-transform:uppercase'></td>
            </tr>
            <tr>
                <td><label for="sub1">Subject 1:</label></td>
                <td><input type="number" name="sub1" autocomplete="off"></td>
            </tr>
            <tr>
                <td><label for="sub2">Subject 2:</label></td>
                <td><input type="number" name="sub2" autocomplete="off"></td>
            </tr>
            <tr>
                <td><label for="sub3">Subject 3:</label></td>
                <td><input type="number" name="sub3" autocomplete="off"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="Submit" name="submit"></td>
            </tr>
        </form>
    </table>
</body>

</html>