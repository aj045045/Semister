<!-- 
*REVIEW - 13.Load the student’s details from studinfo.txt to an array and display all students information
            in tabular format.
-->
<?php
$student = array();
if (file_exists('studinfo.txt')) {
    $fp = fopen('studinfo.txt', 'r');
} else {
    echo "FILE DOES NOT EXISTS TRY TO CREATE A FILES";
}
while (!feof($fp)) {
    $tmp = array(
        fgets($fp),
        fgets($fp),
        fgets($fp),
        fgets($fp),
    );
    array_push($student, $tmp);
}
echo "<table>";
echo "<tr><td class=\"small\">Name </td><td class=\"small\">Semester </td><td class=\"small\">Course</td><td class=\"small\">Roll NO</td></tr>";
foreach ($student as $stu) {
    echo "<tr>";
    foreach ($stu as $val) {
        echo "<td>" . $val . "</td>";
    }
    echo "</tr>";
}
echo "</table>";
?>
<style>
    .small::first-line {
        font-size: .7cm;
    }
</style>