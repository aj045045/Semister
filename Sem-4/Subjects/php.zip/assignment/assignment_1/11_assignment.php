<!-- 
*REVIEW - 11.Create a 2-D array which stores the distance between Source and Destination of five cities in
            KM. Allows user to chose source and Destination from Drop Down list. The script should
            display correct distance between the two cities.
-->
<?php
if (isset($_POST['city'])) {
    $city = $_POST['city'];
    $arr = array(array('Ahmedabad', 20), array('Surat', 100), array('Rajkot', 200), array('Rajasthan', 159), array('Mumbai', 600));
    for ($j = 0; $j < sizeof($arr); $j++) {
        if ($arr[$j][0] === $city) {
            echo "<div>City is " . $arr[$j][0] . " and the distance between is " . $arr[$j][1] . "km </div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question no.11</title>
    <style>
        div {
            font-size: 1cm;
        }
    </style>
</head>

<body>
    <form method="post">
        <select name="city">
            <option value="xyz" selected disabled style="background-color:cornflowerblue;color:aliceblue;">Select city
            *</option>
            <option value="Ahmedabad">Ahmedabad</option>
            <option value="Surat">Surat</option>
            <option value="Rajkot">Rajkot</option>
            <option value="Rajasthan">Rajasthan</option>
            <option value="Mumbai">Mumbai</option>
        </select>
        <input type="submit" value="Submit" name="submit">
    </form>
</body>

</html>