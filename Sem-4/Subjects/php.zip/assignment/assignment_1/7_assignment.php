<!-- 
*REVIEW - 7.Write a PHP script which will display the filesize studinfo.txt and display records. Also provide
            functionality of record navigation by using fseek, ftell and seek in built functions.
-->
<?php

$fp = fopen('studinfo.txt', 'r') or die('UNABLE TO OPEN A FILE !');
echo "File Size is :<b>  " . filesize('studinfo.txt') . "</b><i> bytes</i>";
while (!feof($fp)) {
    echo "<br><i>File pointer at :<b>" . ftell($fp) . "</b> bytes</i><b>" . fgets($fp) . "</b>";
}
echo "<h1> USING FSEEK (SEEK_SET)</h1>";
fseek($fp, 30, SEEK_SET);
while (!feof($fp)) {
    echo "<br><i>File pointer at :<b>" . ftell($fp) . "</b> bytes</i><b>" . fgets($fp) . "</b>";
}
echo "<h1> USING FSEEK (SEEK_CUR)</h1>";
fseek($fp, 30, SEEK_SET);
fseek($fp, 4, SEEK_CUR);
while (!feof($fp)) {
    echo "<br><i>File pointer at :<b>" . ftell($fp) . "</b> bytes</i><b>" . fgets($fp) . "</b>";
}

echo "<h1> USING FSEEK (SEEK_END)</h1>";
fseek($fp, -26, SEEK_END);
while (!feof($fp)) {
    echo "<br><i>File pointer at :<b>" . ftell($fp) . "</b> bytes</i><b>" . fgets($fp) . "</b>";
}
fclose($fp);
?>