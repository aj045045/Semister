<!-- 
*REVIEW - 3.   Write a PHP script which ask user to provide min and max radius value. The script will display
                area of a circle of radius wise. The format should be as follow:
                The area of circle for radius 1 is 3.14 sq meter. [ Min value = 1 ]
-->
<?php
if (isset($_POST['submit'])) {
    $radius = $_POST['radius'] ?: 0;
    define("PI", 3.14);
    $total = PI * $radius * $radius;
    echo "<div>Radius of a circle : <i><b>{$total}</b></i><div>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question no.3</title>
    <style>
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        div {
            font-size: 1.3cm;
            padding: 1cm;
        }
    </style>
</head>

<body>
    <table>
        <tr>
            <form method="post">
                <td><label for="radius">Enter radius :</label></td>
                <td><input type="number" name="radius"></td>
        </tr>
        <tr>
            <td><input type="submit" value="Submit" name="submit"></td>
        </tr>
        </form>
    </table>
</body>

</html>