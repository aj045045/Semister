<!-- 
*REVIEW - 14. Create an array and apply following functions and display the results: 
                i.  each 
                ii. Current 
                iii. Reset 
                iv. End 
                v. pos 
                vi. Prev 
                vii. array_walk 
                viii. Count 
                ix. Sizeof
                x. array_count_values 
                xi. Extract
-->
<?php
function display_array($value, $key, $p)
{
    echo $p . $value . "<br>";
}
$arr = array('aj36' => 'Ansh J Yadav', 'Ekta agja', 'Ekta agja', 'Janvi chauhan', 'Nidhi chavda', 'Harsh dedakiya', 'Tej doshi', 'Aryan hirrpara', 'Trupal lathiya', 'Devansh makwana', 'Ankit yadav');
echo "<h1>Each</h1>";
echo "[Deprecated(reason: \"Use a foreach loop instead)";
echo "<h1>Current</h1>";
echo current($arr) . "<br>";
echo "<h1>Reset</h1>";
echo reset($arr);
echo "<h1>End</h1>";
echo end($arr);
echo "<h1>Pos</h1>";
echo pos($arr);
echo "<h1>Prev</h1>";
echo prev($arr);
echo "<h1>array_walk</h1>";
echo array_walk($arr, 'display_array', 'Name :');
echo "<h1>Count</h1>";
echo "Total element are " . count($arr);
echo "<h1>Sizeof</h1>";
echo sizeof($arr);
echo "<h1>array_count_values</h1>";
print_r(array_count_values($arr));
echo "<h1>Extract</h1>";
extract($arr);
echo $aj36;
?>