<!-- 
*REVIEW - 6.Write a PHP script which will read the students information from the file studinfo.txt and
            display records
-->
<?php
$fp = fopen('studinfo.txt', 'r') or die('UNABLE TO OPEN A FILE !');
while (!feof($fp)) {
    echo "<br>" . fgets($fp);
}
fclose($fp);
?>