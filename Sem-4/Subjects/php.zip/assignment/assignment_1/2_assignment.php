<!--
*REVIEW[epic=Program,seq=2] - 2.Write a PHP and HTML script which ask user to enter his first name and last name and display
            it. The program must get the values by using $_GET, $_POST and $_REQUEST. Check if you
            set method = Get/post and retrieve the variable using $_POST/$_GET.
-->
<?php
if (isset($_REQUEST['submit'])) {
    echo "<div>The First name is : <i><b>" . ucfirst($_REQUEST['firstName']) . "</b></i> and the last name is : <i><b>" . ucfirst($_REQUEST['lastName']) . "</b></i></div>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question no.2</title>
    <style>
        div {
            font-size: 1.3cm;
            padding: 1cm;
        }
    </style>
</head>

<body>
    <table>
        <tr>
            <td style="padding: 50px 100px;">
                <h1> POST METHODS </h1>
                <form method="post">
                    <table>
                        <tr>
                            <td><label for="firstName">First name :</label></td>
                            <td><input type="text" name="firstName"></td>
                        </tr>
                        <tr>
                            <td><label for="lastName">Last name:</label></td>
                            <td><input type="text" name="lastName"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" name="submit" value="Submit">
                            </td>
                        </tr>
                    </table>
                </form>
            </td>
            <td>
                <h1> GET METHODS </h1>
                <form method="get">
                    <table>
                        <tr>
                            <td><label for="firstName">First name :</label></td>
                            <td><input type="text" name="firstName"></td>
                        </tr>
                        <tr>
                            <td><label for="lastName">Last name:</label></td>
                            <td><input type="text" name="lastName"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" name="submit" value="Submit">
                            </td>
                        </tr>
                    </table>
                </form>
            </td>
        </tr>
    </table>
</body>

</html>