<!--
*REVIEW[epic=Class,seq=2] - 10. Using question 8,9 take input from user for three cars maintenance. Add these records into
                                text file. Calculate most economical car and display car details.
-->
<?php
class Vehicle
{
    private $color, $maintenancePerMonth;
    public function __construct($v_color, $v_maintenancePerMonth)
    {
        $this->color = $v_color;
        $this->maintenancePerMonth = $v_maintenancePerMonth;
    }
    public function calculateYearMaintenance()
    {
        return $this->maintenancePerMonth * 12;
    }
    public function getData()
    {
        return "Color is:{$this->color}<br>Maintenance per month is:{$this->maintenancePerMonth}";
    }
}

class Car extends Vehicle
{
    private $engineSize, $numDoors;
    public function __construct($v_engineSize, $v_numDoors, $v_color, $v_maintenancePerMonth)
    {
        $this->engineSize = $v_engineSize;
        $this->numDoors = $v_numDoors;
        parent::__construct($v_color, $v_maintenancePerMonth);
    }
    public function getData()
    {
        return parent::getData() . "<br>Number of Doors is:{$this->numDoors}<br>Engine Size is: {$this->engineSize}<br>";
    }
}

try {
    if (isset($_POST['submit'])) {
        if (filesize("10_ass.txt") <= 0) {
            $fp = fopen("10_ass.txt", "w");
        } else {
            $fp = fopen("10_ass.txt", "a");
        }
        $obj1 = new Car($_POST['engineSize'], $_POST['numDoors'], $_POST['color'], $_POST['costPerMonth']);
        $objString = (string) "\n" . "<br><br>" . $obj1->getData();
        fwrite($fp, $objString);
        fclose($fp);
        if (filesize("10_ass.txt") == 0) {
            throw new Exception("Cannot read a file because the file is empty");
        }
        $fp = fopen("10_ass.txt", "r");
        while (!feof($fp)) {
            echo fgets($fp);
        }
    }
} catch (Exception $er) {
    echo "ERROR : The message is :{$er->getMessage()}<br>At line :{$er->getLine()}";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 11</title>
</head>

<body>
    <form action="" method="post">
        <input type="text" name="color" placeholder="Color"><br>
        <input type="number" name="numDoors" placeholder="Doors"><br>
        <input type="number" name="engineSize" placeholder="Engine"><br>
        <input type="number" name="costPerMonth" placeholder="Enter Cost Per Month"><br>
        <input type="submit" value="submit" name="submit"><br>
    </form>
</body>

</html>