<!-- 
    7. Write a program to calculate factorial value by using recursive function. The value must be
        entered by user.
-->
<?php
function factorial($val)
{
    if ($val >= 1)
        return $val * factorial($val - 1);
    else
        return 1;
}
if (isset($_POST['submit'])) {
    echo factorial($_POST['number'],);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 7</title>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button{
            appearance: none;
            margin:0;
        }
        input[type=number]{
            width:20%;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <input type="number" name="number" placeholder="Enter the number to get factorials">
        <input type="submit" value="Submit" name="submit">
    </form>
</body>

</html>