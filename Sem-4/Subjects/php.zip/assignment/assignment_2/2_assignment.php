<!-- 
    2. Write a php script which ask user to enter username and password. Validate the username by that
        a. username only includes alphanumeric characters only.
        b. Username must begin with character only 
        The password :
        a. Must contain at least one punctuation mark.
        b. Must contain at least one digit 
-->

<?php
    if(isset($_POST['submit']))
    {
        $userName =$_POST['userName'];
        $password =$_POST['password'];
        echo "User Name :".preg_match('/^([A-z])([[:alnum:]])/',$userName,$matchName)."<br>";
        print_r($matchName);
        echo "<br> Password :".preg_match('/[1-9][[:punct:]]/',$password,$matchPassword)."<br>";
        print_r($matchPassword);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 2</title>
</head>
<body>
    <form action="" method="post">
        <input type="text" name="userName" placeholder="Use Name"><br>
        <input type="text" name="password" placeholder="Password"><br>
        <input type="submit" value="Submit" name="submit">
    </form>
</body>
</html>