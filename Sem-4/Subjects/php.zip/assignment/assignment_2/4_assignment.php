<!-- 4. Write a PHP script file which make your pages have the same look. [Hint: use require] -->
<?php
    require "3_assignment.php";
?>

