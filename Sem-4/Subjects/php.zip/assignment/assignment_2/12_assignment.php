<!--
    12. Write an PHP script which allows user to enter product Name, Quantity and Price. Based on
        the price and quantity calculate cost for each item and total cost. Make validation that the
        Quantity and Price must not be blanks and they are must be >=0. If any user enter violates
        the rule, make appropriate exception handling.
-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 9</title>
</head>

<body>
    <form action="" method="post">
        <input type="text" name="productName" placeholder="Enter the Product Name"><br>
        <input type="number" name="quantity" placeholder="Enter the Quantity"><br>
        <input type="number" name="price" placeholder="Enter the price"><br>
        <input type="submit" value="submit" name="submit"><br>
    </form>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    try {
        $price = $_POST['price'];
        $productName = $_POST['productName'];
        $quantity = $_POST['quantity'];
        if ($quantity <= 0 && $price <= 0) {
            throw new Exception("The price and quantity is less than or equal to zero");
        }
        if ($price <= 0) {
            throw new Exception("The price is less than or equal to zero");
        }
        if ($quantity <= 0) {
            throw new Exception("The Quantity is less than or equal to zero");
        }
        $total = $quantity * $price;
        echo "The Total cost of product {$productName} is {$total}";
    } catch (Exception $exp) {
        echo "ERROR : {$exp->getMessage()}<br>At line no:{$exp->getLine()}<br>Of a file:{$exp->getFile()}";
    }
}
?>