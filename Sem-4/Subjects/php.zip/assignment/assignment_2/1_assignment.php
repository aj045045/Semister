<!--!
    1. Write a simple php script which evaluates following string functions and display the output:
        i. ltrim ii. Rtrim iii. Trim iv. Str_pad v. Lcfirst vi. Ucfirst vii. Ucwords viii.ucfirst ix. Strtolower
        x. Strtoupper xi. Strrev xii. Str_shuffle xiii. Str_repeat xiv. Explode xv. Implode xvi. Strcmp
        xvii. Strcasecmp xviii. Strcasecmp xix. Strnatcmp xx. Strnatcasecmp xxi. Strlen xxii. Strstr
        xxiii. Strchr xxiv. Strrchr xxv. Stristr xxvi. Strpos xxvii. Strrpos xxviii. Str_replace xxix.Substr_replace
-->
<?php

echo "i. ltrim :" . ltrim("    Ansh J Yadav")."<br>";
echo "ii. Rtrim :" .rtrim("Ansh J Yadav         "). "<br>";
echo "iii. Trim :" .trim("           Ansh J Yadav           ")."<br>";
echo "iv. Str_pad :" .str_pad("To be continued",20,"."). "<br>";
echo "v. Lcfirst :" .lcfirst("TO BE A DEVELOPER"). "<br>";
echo "vi. Ucfirst :" .ucfirst("to be a developer"). "<br>";
echo "vii. Ucwords :" .ucwords("to be a developer"). "<br>";
echo "viii.ucfirst :".ucfirst("to be a developer"). "<br>";
echo "ix. Strtolower :" .strtolower("TO BE A PROGRAMMER"). "<br>";
echo "x. Strtoupper :" .strtoupper("to be a programmer"). "<br>";
echo "xi. Strrev :" .strrev("ANSH"). "<br>";
echo "xii. Str_shuffle :" .str_shuffle("To be a developer"). "<br>";
echo "xiii. Str_repeat :" .str_repeat("To be",5). "<br>";
echo "xiv. Explode :"; print_r(explode(" ","To be a Programmer")). "<br>";
    $arr = array('To','be','a','Programmer');
echo "<br>xv. Implode :" .implode(" ",$arr). "<br>";
echo "xvi. Strcmp :" .strcmp("Programmer","pROGRAMMER"). "<br>";
echo "xvii. Strcasecmp :" .strcasecmp("Programmer","Programmer"). "<br>";
echo "xviii. Strcasecmp :" .strcasecmp("Programmer","PROGRAMMER"). "<br>";
echo "xix. Strnatcmp :" .strnatcmp("2Programmer","1Programmer"). "<br>";
echo "xx. Strnatcasecmp :" .strnatcmp("1Programmer","2Programmer"). "<br>";
echo "xxi. Strlen :" .strlen("To be a Developer"). "<br>";
echo "xxii. Strstr :" .strstr("To be a Programmers","Programmer"). "<br>";
echo "xxiii. Strchr :" .strstr("To be a Programmers","Programmer"). "<br>";
echo "xxiv. Strrchr :" .strrchr("To be a Developer To be a Developer","Developer"). "<br>";
echo "xxv. Stristr :" .stristr("To be a Developer","DEVELOPER"). "<br>";
echo "xxvi. Strpos :" .strpos("I love php, I love php too!","php"). "<br>";
echo "xxvii. Strrpos :" .strrpos("I love php, I love php too!","php"). "<br>";
echo "xxviii. Str_replace : " .str_replace("world","Peter","Hello world!"). "<br>";
echo "xxix.Substr_replace :"  .substr_replace("Hello ansh","world",0). "<br>";
?>


