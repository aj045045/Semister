<!-- 
    9. Create a class Car which is child class of the class Vehicle. Add the operation maintenance for
        car class. The maintenance class has a property to calculate cost to maintain a car in good
        condition for a month. Write a function which provides the total maintenance cost of a car
        for the year.
-->
<?php
class Vehicle
{
    private $type, $color, $fuelType, $maintenancePerMonth;
    public function __construct($v_type, $v_color, $v_fuelType, $v_maintenancePerMonth)
    {
        $this->type = $v_type;
        $this->color = $v_color;
        $this->fuelType = $v_fuelType;
        $this->maintenancePerMonth = $v_maintenancePerMonth;
    }
    public function calculateYearMaintenance()
    {
        return $this->maintenancePerMonth * 12;
    }
    public function getData()
    {
        echo"
        Car type is a : ".ucfirst($this->type)." car <br>
        Color is: {$this->color} <br>
        Fuel Type is: {$this->fuelType}<br>Yearly Maintenance of the car is :" . self::calculateYearMaintenance() ."<br>";
    }
}

class Car extends Vehicle
{
    private $engineSize, $numDoors;
    public function __construct($v_engineSize, $v_numDoors, $v_type, $v_color, $v_fuelType, $v_maintenancePerMonth)
    {
        $this->engineSize = $v_engineSize;
        $this->numDoors = $v_numDoors;
        parent::__construct($v_type, $v_color, $v_fuelType, $v_maintenancePerMonth);
    }
    public function getData()
    {
        parent::getData();
        echo "
        Number of Doors is:{$this->numDoors}<br>
        Engine Size is: {$this->engineSize}<br>";
    }
}

if (isset($_POST['submit'])) {
    $obj1 = new Car($_POST['engineSize'], $_POST['numDoors'], $_POST['type'], $_POST['color'], $_POST['fuelType'], $_POST['costPerMonth']);
    $obj1->getData();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 9</title>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-inner-outer-button{
            appearance: none;
            margin :0;
        }
        input,select{
            margin:5px;
            width:1.5in;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <select name="type" >
            <option disabled selected>Select Cars</option>
            <option value="sports">Sports Cars</option>
            <option value="Super">Super Cars</option>
            <option value="sedan">Sedan Car</option>
            <option value="coupe">Coupe Car</option>
            <option value="limousine">Limousine</option>
            <option value="roadster">Roadster</option>
        </select><br>
        <input type="text" name="color" placeholder="Color"> <br>
        <input type="number" name="numDoors" placeholder="Doors"> <br>
        <input type="number" name="engineSize" placeholder="Engine"> <br>
        <input type="text" name="fuelType" placeholder="Fuel"> <br>
        <input type="number" name="costPerMonth" placeholder="Enter Cost Per Month"> <br>
        <input type="submit" value="submit" name="submit"> <br>
    </form>
</body>

</html>