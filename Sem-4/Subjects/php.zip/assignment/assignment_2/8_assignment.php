<!-- 
*REVIEW[epic=Class,seq=1] - 8. Create a class Vehicle having attributes VID, ModelNo and Mileage( per liter). Write
                                operations to calculate cost per Km by asking price of fuel from user. Implement all the
                                attributes and operations for the class.
-->
<?php

class Vehicle
{
    private $vId, $modelName, $milage;
    public function __construct($v_vId, $v_modelNo, $v_milage)
    {
        $this->vId = $v_vId;
        $this->modelName = $v_modelNo;
        $this->milage = $v_milage;
    }
    public function calculatePricePerKilometer($cost)
    {
        return $cost / $this->milage;
    }
    public function displayVehicle($cost)
    {
        echo "<div class=\"display\">The model no is \"".$this->vId."\" and the model name is \"".$this->modelName."\" whose milage is <strong>".$this->milage."</strong> and the cost per kilometer is ".self::calculatePricePerKilometer($cost)." <strong>Per km</strong></div>";
    }
}

if (isset($_POST['submit'])) {
    $obj1=new Vehicle($_POST['id'],$_POST['modelNo'],$_POST['milage']);
        echo $obj1->displayVehicle($_POST['fuel']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 8</title>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button{
            appearance: none;

        }
        form > input{
            margin:10px 0px;
            display: block;
            width: 20%;
        }
        .display{
            font-size: x-large;
        }
        </style>
</head>

<body>
    <form action="" method="post">
        <input type="number" name="id" id="" placeholder="Enter the model number">
        <input type="text" name="modelNo" id="" placeholder="Enter the model name">
        <input type="number" name="milage" id="" placeholder="Enter the Milage">
        <input type="number" name="fuel" id="" placeholder="Enter the Price of fuel per liter">
        <input type="submit" value="Submit" name="submit">
    </form>
</body>

</html>