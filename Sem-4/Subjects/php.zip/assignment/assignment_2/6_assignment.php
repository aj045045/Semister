<!--
    6. Write a function which takes 5 number of input as array from user. Then calculate total and
        average and display total and average of the 5 numbers.[Hint: use & to return multiple values] 
-->

<?php
function calculateAverage($marks)
{
    $total = calculateTotal($marks);
    $average = $total / 5;
    return $average;
}

function calculateTotal($marks)
{
    $total = 0;
    foreach ($marks as $val) {
        $total += $val;
    }
    return $total;
}

function checkValues($marks)
{
    foreach ($marks as $val) {
        if ($val >= 100) {
            return 1;
        }
    }
    return 0;
}
try {

    if (isset($_POST['submit'])) {
        $marks = $_POST['marks'];
        if (checkValues($marks)) {
            throw new Exception("The marks is greater than ( > ) 100");
        }
        $average = calculateAverage($marks);
        $total = calculateTotal($marks);
        echo <<<theEnd
        Total is : $total <br>
        and its, <br>
        Average is : $average
        theEnd;
    }
} catch (Exception $exp) {
    echo "<div class=\"error\">Error :<i> " . $exp->getMessage() . "</i> at line number " . $exp->getLine() . " in the File <strong>" . $exp->getFile() . "</strong></div>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 6</title>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            appearance: none;
            margin: 0;
        }

        .error {
            font-size: x-large;
        }

        input[type=number] {
            margin: 5px 0px;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <?php
        for ($i = 1; $i <= 5; $i++) {
            echo "<input type=\"number\" name=\"marks[]\" placeholder=\"Enter {$i} subject marks\"><br>";
        }
        ?>
        <input type="submit" value="calculate" name="submit">
    </form>
</body>

</html>