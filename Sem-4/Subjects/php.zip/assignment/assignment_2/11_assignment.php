<!--
    11.Make Exception handling for Question No. 10.
-->
<?php
class Vehicle
{
    private $color, $maintenancePerMonth;
    public function __construct($v_color, $v_maintenancePerMonth)
    {
        $this->color = $v_color;
        $this->maintenancePerMonth = $v_maintenancePerMonth;
    }
    public function calculateYearMaintenance()
    {
        return $this->maintenancePerMonth * 12;
    }
    public function getData()
    {
        return "Color is:{$this->color}<br>Maintenance per month is:{$this->maintenancePerMonth}";
    }
    public function getCostPerMonth()
    {
        return $this->maintenancePerMonth;
    }
}

class Car extends Vehicle
{
    private $engineSize, $numDoors;
    public function __construct($v_engineSize, $v_numDoors, $v_color, $v_maintenancePerMonth)
    {
        $this->engineSize = $v_engineSize;
        $this->numDoors = $v_numDoors;
        parent::__construct($v_color, $v_maintenancePerMonth);
    }
    public function getData()
    {
        return parent::getData() . "<br>Number of Doors is:{$this->numDoors}<br>Engine Size is: {$this->engineSize}<br>";
    }
}

if (isset($_POST['submit'])) {
    if (filesize("10_ass.txt") <= 0) {
        $fp = fopen("10_ass.txt", "w");
    } else {
        $fp = fopen("10_ass.txt", "a");
    }
    $num = $_POST['numOfForm'];
    $object = array();
    $valueArray = array();
    $arrayOfMaintenance = array();
    array_push($valueArray, $_POST['engineSize'], $_POST['numDoors'], $_POST['color'], $_POST['costPerMonth']);
    for ($i = 0; $i < $num; $i++) {
        $obj1 = new Car($valueArray[0][$i], $valueArray[1][$i], $valueArray[2][$i], $valueArray[3][$i]);
        $objString = (string) "\n" . ($obj1->getData()) . "<br><br>";
        array_push($object, $obj1);
        array_push($arrayOfMaintenance, $obj1->getCostPerMonth());
        fwrite($fp, $objString);
    }
    $valueIndex = array_search(min($arrayOfMaintenance), $arrayOfMaintenance);
    echo "======MIN VALUE ======== <br>";
    print_r($object[$valueIndex]->getData());
    echo "<br> ================= <br>";
    fclose($fp);
    $fp = fopen("10_ass.txt", "r");
    while (!feof($fp)) {
        echo fgets($fp);
    }
    fclose($fp);
}

if (isset($_POST['SubmitMultiForm'])) {
    $num = $_POST['multiform'];
    echo "<form action=\"\" method=\"post\">";
    for ($i = 0; $i < $num; $i++) {
        echo "<input type=\"text\" name=\"color[]\" placeholder=\"Color\"><br>
    <input type=\"number\" name=\"numDoors[]\" placeholder=\"Doors\"><br>
    <input type=\"number\" name=\"engineSize[]\" placeholder=\"Engine\"><br>
    <input type=\"number\" name=\"costPerMonth[]\" placeholder=\"Enter Cost Per Month\"><br><br><br>";
    }
    echo "<input type=\"hidden\" value=\"{$num}\" name=\"numOfForm\"><br><input type=\"submit\" value=\"submit\" name=\"submit\"><br></form>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 10</title>
</head>

<body>
    <form action="" method="post">
        <input type="number" name="multiform">
        <input type="submit" value="SubmitMultiForm" name="SubmitMultiForm">
    </form>
</body>

</html>