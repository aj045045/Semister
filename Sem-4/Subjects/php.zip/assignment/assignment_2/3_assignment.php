<!--
    3. Write a PHP script which allows user to enter product code, product name, product price and
        discount percentage. The program must use a function to calculate discounted amount
        calculate net pay amount.
-->
<?php
if (isset($_POST['submit'])) {
    $productCode = $_POST['productCode'];
    $productName = $_POST['productName'];
    $productPrice = $_POST['productPrice'];
    $productDiscount = $_POST['productDiscount'];
    $productDiscountAmount = $productPrice * $productDiscount / 100;
    $productNetPay = $productPrice - $productDiscountAmount;
    echo "Product Code :$productCode <br>Product Name :$productName <br>Product Price :$productPrice <br>Product Discount Rate :$productDiscount <br> Product Discount Amount :$productDiscountAmount <br>Product Net Pay amount :$productNetPay <br><br>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 3</title>
    <style>
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            margin: 0;
            appearance: none;
        }
    </style>
</head>

<body>
    <form method="post">
        <input type="number" name="productCode" placeholder="Product Code"><br>
        <input type="text" name="productName" placeholder="Product Name"><br>
        <input type="number" name="productPrice" placeholder="Product Price"><br>
        <input type="number" name="productDiscount" placeholder="Product Discount in %"><br>
        <input type="submit" value="Submit" name="submit">
    </form>
</body>

</html>