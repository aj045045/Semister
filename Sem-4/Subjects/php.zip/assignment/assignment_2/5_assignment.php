<!-- 
    5. Write a PHP function which ask the user number of tickets to be booked. The function get
        the no. of booked tickets and create a table based on that which have exactly same rows as
        number entered by user. The value for rows are booked ticket numbers.
-->

<?php
function showBookedTicket($val)
{
    echo " <form action=\"\"  method=\"post\"> ";
    for ($i = 0; $i < $val; $i++) {
        echo " <input type=\"number\" placeholder=\"Enter the seat number\" name=\"ticket[]\">";
    }
    echo "<input type=\"submit\" value=\"Submit\" name=\"submitForm\"></form>";
}

if (isset($_POST['submitForm'])) {
    echo "<table>
    <th><td>Seat Number</td></th>";
    $val = $_POST['ticket'];
    foreach ($val as $seat) {
        echo "<tr>
        <td> {$seat} </td>
        </tr>";
    }
    echo "</table>";
}

if (isset($_POST['submit'])) {
    showBookedTicket($_POST['numberOfTicket']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 5</title>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            appearance: none;
            margin: 0;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <input type="number" name="numberOfTicket" placeholder="Enter number of Tickets">
        <input type="submit" value="Submit" name="submit">
    </form>
</body>

</html>