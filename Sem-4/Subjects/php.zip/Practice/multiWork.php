<?php

interface users
{
    public function getData();
}
class User implements users
{
    private $name, $course, $age, $about;
    function __construct($v_name, $v_course, $v_age, $v_about)
    {
        $this->name = $v_name;
        $this->course = $v_course;
        $this->age = $v_age;
        $this->about = $v_about;
    }
    function getData()
    {
        return "The name is {$this->name} of course {$this->course} and the age is {$this->age} the details is {$this->about}<br>";
    }
}

class Student extends User implements users
{
    private $roll, $sem;
    function __construct($v_name, $v_course, $v_age, $v_roll, $v_sem, $v_about)
    {
        $this->roll = $v_roll;
        $this->sem = $v_sem;
        parent::__construct($v_name, $v_course, $v_age, $v_about);
    }
    function getData()
    {

        return parent::getData() . " the roll.no is {$this->roll} and the sem is {$this->sem}<br><br>\n";
    }
}

if (isset($_POST['submit'])) {
    try {
        $type = strtoupper($_POST['user']);
        $name = ucfirst($_POST['name']);
        $course = ucfirst($_POST['course']);
        $age =  $_POST['age'];
        $roll = $_POST['roll'];
        $sem = $_POST['sem'];
        $about = trim(ucwords($_POST['about']));
        if ($age <= 0 || $sem <= 0) {
            throw new Exception("Age or Sem is Less than or Equal to ZERO");
        }
        if ($type == 'STU') {
            $stu = new Student($name, $course, $age, $roll, $sem, $about);
            echo $stu->getData();
        } else {
            throw new Exception("Their is no faculty in the Department");
        }
        $dt = new DateTime();
        $date = $dt->format('Y-m-d H:i:s');
        $dns = "mysql:host=localhost;dbname=demodb";
        $user = "root";
        $pwd = "";
        $db = new PDO($dns, $user, $pwd);
        $result = $db->prepare("INSERT INTO user_pra VAlUE('','$name','$roll','$course','$sem','$age','$about','$date','$type')");
        if ($result->execute()) {
            echo "Data Submitted Successful to the data Base<br> ";
        } else {
            throw new Exception("Data cannot be inserted in the DataBase");
        }
        $result->closeCursor();
        $writeWork = (string)$stu->getData();
        $fileName = (string)"multiWork.txt";
        if (!file_exists($fileName) || filesize($fileName) <= 0) {
            $file = fopen($fileName, 'w');
        } else {
            $file = fopen($fileName, 'a');
        }
        if (file_exists($fileName)) {
            if (fwrite($file, $writeWork)) {
                // echo $writeWork;
                echo "Data Successful Write in the text file named multiWork.txt";
            } else {
                throw new Exception("Data cannot be submitted to text file ");
            }
            fclose($file);
        } else {
            throw new Exception("File name multiWork.txt does not exists");
        }
        echo "<h3>From Text File </h3>";
        $fp = fopen($fileName, "r");
        if (filesize($fileName) >= 0) {
            while (!feof($fp)) {
                echo fgets($fp, filesize($fileName));
            }
        }
        fclose($fp);
        echo "<br><br><h3> From Data Base</h3>";
        $result = $db->query("SELECT * FROM user_pra");
        $rows = $result->fetchAll(PDO::FETCH_BOTH);
        if (count($rows) > 0) {
            foreach ($rows as $row) {
                echo "The id is " . $row['id'] . "<br>The name is " . $row['name'] . "<br>The rollNO is " . $row['rollNo'] . "<br>The course is " . $row['course'] . "<br>The sem is " . $row['sem'] . "<br>The age is " . $row['age'] . "<br>About :" . $row['about'] . "<br>The Date is " . $row['loginDate'] . "<br>The user type is " . $row['type'] . "<br><br><br>";
            }
        }
        $result->closeCursor();
    } catch (Exception $exp) {
        echo "ERROR :" . $exp->getMessage() . " at the line number " . $exp->getLine() . " on the file " . $exp->getFile();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multi Task Works</title>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            appearance: none;
            margin: 0;
        }

        input,
        select {
            width: 20%;
            margin: 5px 0px;
            height: 20px;
        }
    </style>
</head>

<body>
    <form method="post">
        <select name="user" require>
            <option selected disabled>Select the user type </option>
            <option value="fac">Faculty </option>
            <option value="stu">Student </option>
        </select><br>
        <input type="text" name="name" require placeholder="Name"><br>
        <input type="number" name="roll" require placeholder="Roll Number"><br>
        <input type="number" name="age" require placeholder="Age"><br>
        <select name="course" require>
            <option selected disabled>Select the course</option>
            <option value="msc(cs)">msc(cs) </option>
            <option value="pgdcsa">pgdcsa </option>
            <option value="aiml">aiml</option>
            <option value="mtec">mtech </option>
        </select><br>
        <input type="number" name="sem" require placeholder="Sem"><br>
        <input type="text" name="about" require placeholder="About"><br>
        <input type="submit" value="submit" name="submit">
    </form>
</body>

</html>