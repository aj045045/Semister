<!--
    1)  Define a structure of book store with appropriate data members. Read the information of book store  
        and display the information in proper format.
-->

<?php
class book
{
    private $publisher;
    private $title;
    private $price = 0;
    private $author;
    public function __construct($v_publisher, $v_title, $v_price, $v_author)
    {
        $this->publisher = $v_publisher;
        $this->title = $v_title;
        $this->price = $v_price;
        $this->author = $v_author;
    }
    public function display()
    {

        echo "
        Name of the book is :{$this->publisher}  <br>
        Title  of the book is :{$this->title} <br>
        Price of the book is :{$this->price} <br>
        Author of the book is :{$this->author} <br><br><br>
        ";
    }
    public function __destruct()
    {
        echo "THANKS FOR COMMING";
    }
}

if (isset($_POST['range'])) {

    echo " <form action=\"\" method=\"post\">";
    for ($i = 0; $i < $_POST['nums']; $i++) {
        $j = $i + 1;
        echo " <br><b>Number :$j <b/> <br>
        <input type=\"text\" name=\"publisher$j\" placeholder=\"Publisher \"> <br>
        <input type=\"text\" name=\"title$j\" placeholder=\"Title\"> <br>
        <input type=\"tel\" name=\"price$j\"  placeholder=\"Price\"> <br>
        <input type=\"text\" name=\"author$j\" placeholder=\"Author\"> <br>";
    }
    echo "<br>
    <input type=\"hidden\" name=\"rangetarget\" value=\"$j\">    
    <input type=\"submit\" name=\"submit\" value=\"submit\" > <br><br>
    </form>";
}
if (isset($_POST['submit'])) {
    $aj = array();
    for ($i = 0; $i < $_POST['rangetarget']; $i++) {
        $j = $i + 1;
        $aj[$i] = new book($_POST['publisher' . $j], $_POST['title' . $j], $_POST['price' . $j], $_POST['author' . $j]);
    }
    for ($i = 0; $i < $_POST['rangetarget']; $i++) {
        $aj[$i]->display();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practice 1</title>
    <style></style>
</head>

<body>
    <form action="" method="post">
        <input type="tel" name="nums" placeholder="Enter the range ">
        <input type="submit" value="Submit" name="range">
    </form>
</body>

</html>