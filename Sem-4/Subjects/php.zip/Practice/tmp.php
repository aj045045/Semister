<?php
    $todayDt = new DateTime();
    $newDate = new DateTime('2023-05-13');
    $dateDiffer = date_diff($todayDt,$newDate);
    if($dateDiffer->format('%R%a') <= 0)
    {
        
    }
